/* Delta88 running SVR4.  */

#include <unistd.h>

#define STDC_HEADERS
#include "hosts/std-host.h"

#define HAVE_PROCFS	/* This host has /proc support */
