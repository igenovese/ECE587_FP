/* tm.h file for a Convex C38xx.  */

#define TARGET_DEFAULT 020

#include "convex/convex.h"
